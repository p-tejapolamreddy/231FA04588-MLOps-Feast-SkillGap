# Curriculum-Industry Skill Feature Store Using Feast

## Student Details
- **Name:** Tejaswini
- **Register Number:** `<YOUR_REGISTER_NUMBER>`
- **Section:** `<YOUR_SECTION>`

> Replace the two placeholders above before pushing to GitHub.

## Problem Statement
The project converts a curriculum-industry skill-gap dataset into a reusable Feast feature store. The objective is to identify skills where industry demand is higher than the current curriculum coverage and make engineered features available consistently for model training and prediction.

## Dataset
- **Number of skills:** 40
- **Dataset columns:** `skill_id`, `skill_name`, `domain`, `curriculum_score`, `industry_demand`, `target`, `timestamp`
- **Target:** `1` indicates that the skill is a high-priority training gap; `0` indicates lower priority.
- **How entries were created:** The dataset is a small educational demonstration dataset. Skill names cover programming, web, cloud, AI, data, DevOps, analytics, systems, security, software engineering and design. Curriculum and industry scores are normalized from 0 to 1 to make feature engineering simple and reproducible.

## Feature Engineering
The original dataset is transformed into `skill_features.parquet`.

| Feast feature | Meaning |
|---|---|
| `curriculum_score` | Normalized curriculum coverage of the skill. |
| `industry_demand` | Normalized industry demand for the skill. |
| `skill_gap` | `industry_demand - curriculum_score`. Positive values indicate a gap. |
| `gap_abs` | Absolute value of the skill gap. |
| `demand_weighted_gap` | Positive gap weighted by industry demand. |
| `readiness_score` | A combined score using curriculum coverage and the positive gap. |
| `target` | Training-priority label used by the model. |

### Example calculation
For React, curriculum score = 0.48 and industry demand = 0.88.

`skill_gap = 0.88 - 0.48 = 0.40`

The positive gap shows that industry demand is substantially higher than curriculum coverage.

## Feast Architecture

```text
Original Dataset
      |
      v
Feature Engineering
      |
      v
Parquet Offline Data
      |
      v
Feast FeatureView
      |
      +----------------------+
      |                      |
      v                      v
Historical Features      Materialization
      |                      |
      v                      v
Model Training          Online Store
                             |
                             v
                       Online Retrieval
                             |
                             v
                         Prediction
```

## Implementation
### 1. Entity
The Feast entity is `skill_id`. Each skill is uniquely identified by an ID such as `S005`.

### 2. Data source
The `FileSource` points to `data/skill_features.parquet`, using `timestamp` as the event timestamp.

### 3. FeatureView
The FeatureView is named `skill_gap_features`. It contains the engineered numeric features and the target.

### 4. Historical retrieval
`get_historical_features()` joins the entity/timestamp dataframe with the requested FeatureView features. The result is saved as `outputs/historical_features.csv`.

### 5. Model
A Logistic Regression model is trained using the Feast feature dataset. The model predicts whether a skill should be treated as a high-priority training gap.

### 6. Online retrieval
After materialization, `get_online_features()` retrieves the latest feature values for requested skill IDs from the online store.

## Required Analysis Questions

### 1. What is the entity in your Feast implementation?
The entity is `skill_id`, which uniquely identifies each skill.

### 2. List the features stored in your FeatureView.
`curriculum_score`, `industry_demand`, `skill_gap`, `gap_abs`, `demand_weighted_gap`, `readiness_score`, and `target`.

### 3. Explain how one feature was calculated.
`skill_gap` is calculated as `industry_demand - curriculum_score`. For example, React has 0.88 industry demand and 0.48 curriculum coverage, so its gap is 0.40.

### 4. What is the difference between your original dataset and the feature dataset?
The original dataset contains descriptive skill information and the base curriculum/industry scores. The feature dataset adds engineered numeric features designed for consistent machine-learning training and serving.

### 5. What is the purpose of the offline store?
The offline store keeps historical feature data used for training and historical feature retrieval. In this project, the file-based source is Parquet.

### 6. What is the purpose of the online store?
The online store keeps the latest materialized feature values so applications can retrieve features quickly during prediction.

### 7. What is the purpose of `feast apply`?
`feast apply` registers the Feast entities, data sources and FeatureViews defined in the repository with the Feast registry.

### 8. What does materialization do?
Materialization loads feature values from the historical/offline source into the online store for online serving.

### 9. What is the advantage of retrieving features through Feast instead of manually calculating them separately during training and prediction?
Feast provides one managed definition of the features for both historical training and online prediction. This reduces duplicated feature logic and helps keep training and serving features consistent.

### 10. State two limitations of your current dataset.
1. The dataset is small and manually constructed for demonstration, so it does not represent the full labor market.
2. Curriculum and industry scores are simplified normalized values rather than measurements collected from large real-world sources.

### 11. State two ways your feature store could be improved when more curriculum and industry evidence becomes available.
1. Add regularly updated evidence from job postings, employer surveys, course outcomes and curriculum documents.
2. Add time-aware features such as demand trends, skill popularity changes and department-level curriculum coverage.

## How to Run

### 1. Create an environment
```bash
python -m venv .venv
```
Activate it and install dependencies:

```bash
pip install -r requirements.txt
```

### 2. Generate the Parquet feature dataset and train the model
```bash
python run_all.py
```

### 3. Register Feast objects
```bash
feast apply
```

### 4. Retrieve historical features
```bash
python src/historical_retrieval.py
```

### 5. Materialize the online store
```bash
python src/materialize_online.py
```

### 6. Retrieve online features
```bash
python src/online_retrieval.py
```

### 7. Produce the final prediction
```bash
python src/final_prediction.py
```

## Results
After running the commands above, include these generated artifacts in the GitHub repository:
- `outputs/historical_features.csv`
- `outputs/model_accuracy.txt`
- `outputs/online_features.txt`
- `outputs/final_prediction.txt`

The final prediction in this demonstration uses skill `S038` (`LLM_Applications`) as the online inference example.

## Submission
Repository name:

`<YOUR_REGISTER_NUMBER>-MLOps-Feast-SkillGap`

Upload the complete repository to GitHub and submit the repository link through the faculty Google Form, as required by the assignment.
