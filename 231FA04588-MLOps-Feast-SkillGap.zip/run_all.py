from pathlib import Path
import subprocess, sys
ROOT = Path(__file__).resolve().parent
for script in ["src/prepare_features.py", "src/train_model.py"]:
    subprocess.run([sys.executable, str(ROOT / script)], check=True)
print("Next run these Feast commands from this repository:")
print("  feast apply")
print("  python src/historical_retrieval.py")
print("  python src/materialize_online.py")
print("  python src/online_retrieval.py")
print("  python src/final_prediction.py")
