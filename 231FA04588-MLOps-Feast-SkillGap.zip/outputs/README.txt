These files contain locally generated demonstration outputs from the same feature-engineering logic.
Run the Feast commands in the repository after installing requirements to generate the Feast-backed outputs.
