from pathlib import Path
import pandas as pd
import joblib
from feast import FeatureStore

ROOT = Path(__file__).resolve().parents[1]
model = joblib.load(ROOT / "outputs" / "skill_gap_model.joblib")
store = FeatureStore(repo_path=str(ROOT))
response = store.get_online_features(
    features=[
        "skill_gap_features:curriculum_score",
        "skill_gap_features:industry_demand",
        "skill_gap_features:skill_gap",
        "skill_gap_features:gap_abs",
        "skill_gap_features:demand_weighted_gap",
        "skill_gap_features:readiness_score",
    ],
    entity_rows=[{"skill_id": "S038"}],
).to_df()
cols = ["curriculum_score", "industry_demand", "skill_gap", "gap_abs", "demand_weighted_gap", "readiness_score"]
pred = int(model.predict(response[cols])[0])
prob = float(model.predict_proba(response[cols])[0][1])
print(f"Skill: S038 (LLM_Applications)")
print(f"Predicted training priority: {pred}")
print(f"Probability of priority=1: {prob:.4f}")
with open(ROOT / "outputs" / "final_prediction.txt", "w") as f:
    f.write(f"Skill: S038 (LLM_Applications)\nPredicted training priority: {pred}\nProbability: {prob:.4f}\n")
