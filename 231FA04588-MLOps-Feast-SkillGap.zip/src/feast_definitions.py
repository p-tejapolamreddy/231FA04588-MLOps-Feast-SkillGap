from datetime import timedelta
from feast import Entity, FeatureView, Field, FileSource
from feast.types import Float32, Int64

skill = Entity(name="skill_id", join_keys=["skill_id"], description="A curriculum/industry skill")

skill_source = FileSource(
    name="skill_features_source",
    path="data/skill_features.parquet",
    timestamp_field="timestamp",
)

skill_features = FeatureView(
    name="skill_gap_features",
    entities=[skill],
    ttl=timedelta(days=365),
    schema=[
        Field(name="curriculum_score", dtype=Float32),
        Field(name="industry_demand", dtype=Float32),
        Field(name="skill_gap", dtype=Float32),
        Field(name="gap_abs", dtype=Float32),
        Field(name="demand_weighted_gap", dtype=Float32),
        Field(name="readiness_score", dtype=Float32),
        Field(name="target", dtype=Int64),
    ],
    source=skill_source,
    online=True,
)
