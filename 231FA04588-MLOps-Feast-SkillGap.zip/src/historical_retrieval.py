from pathlib import Path
import pandas as pd
from feast import FeatureStore

ROOT = Path(__file__).resolve().parents[1]
store = FeatureStore(repo_path=str(ROOT))
entity_df = pd.read_parquet(ROOT / "data" / "skill_features.parquet")[["skill_id", "timestamp"]]
job = store.get_historical_features(
    entity_df=entity_df,
    features=[
        "skill_gap_features:curriculum_score",
        "skill_gap_features:industry_demand",
        "skill_gap_features:skill_gap",
        "skill_gap_features:gap_abs",
        "skill_gap_features:demand_weighted_gap",
        "skill_gap_features:readiness_score",
        "skill_gap_features:target",
    ],
)
out = job.to_df()
out.to_csv(ROOT / "outputs" / "historical_features.csv", index=False)
print(out.head(10).to_string(index=False))
