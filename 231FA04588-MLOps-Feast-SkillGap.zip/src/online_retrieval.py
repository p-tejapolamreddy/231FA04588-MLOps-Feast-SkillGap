from pathlib import Path
from feast import FeatureStore

ROOT = Path(__file__).resolve().parents[1]
store = FeatureStore(repo_path=str(ROOT))
response = store.get_online_features(
    features=[
        "skill_gap_features:curriculum_score",
        "skill_gap_features:industry_demand",
        "skill_gap_features:skill_gap",
        "skill_gap_features:gap_abs",
        "skill_gap_features:demand_weighted_gap",
        "skill_gap_features:readiness_score",
        "skill_gap_features:target",
    ],
    entity_rows=[{"skill_id": "S005"}, {"skill_id": "S038"}],
).to_dict()
print(response)
with open(ROOT / "outputs" / "online_features.txt", "w") as f:
    f.write(str(response))
