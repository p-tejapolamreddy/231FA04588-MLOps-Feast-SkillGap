from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
raw = pd.read_csv(ROOT / "data" / "skills.csv", parse_dates=["timestamp"])

# Feature engineering: convert curriculum/industry scores into reusable model features.
features = raw[["skill_id", "timestamp", "curriculum_score", "industry_demand", "target"]].copy()
features["skill_gap"] = (features["industry_demand"] - features["curriculum_score"]).round(4)
features["gap_abs"] = features["skill_gap"].abs().round(4)
features["demand_weighted_gap"] = (
    features["industry_demand"] * features["skill_gap"].clip(lower=0)
).round(4)
features["readiness_score"] = (
    0.6 * features["curriculum_score"] + 0.4 * (1 - features["skill_gap"].clip(lower=0))
).round(4)

out = ROOT / "data" / "skill_features.parquet"
out.parent.mkdir(exist_ok=True)
features.to_parquet(out, index=False)
print(f"Wrote {len(features)} rows to {out}")
print(features.head(10).to_string(index=False))
