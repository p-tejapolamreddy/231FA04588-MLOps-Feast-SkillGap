from pathlib import Path
from feast import FeatureStore

ROOT = Path(__file__).resolve().parents[1]
store = FeatureStore(repo_path=str(ROOT))
store.materialize_incremental(end_date=None)
print("Online store materialization completed.")
