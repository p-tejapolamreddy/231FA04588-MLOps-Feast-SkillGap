from pathlib import Path
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report
import joblib

ROOT = Path(__file__).resolve().parents[1]
df = pd.read_parquet(ROOT / "data" / "skill_features.parquet")
feature_cols = [
    "curriculum_score", "industry_demand", "skill_gap",
    "gap_abs", "demand_weighted_gap", "readiness_score"
]
X = df[feature_cols]
y = df["target"]
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)
model = LogisticRegression(max_iter=2000)
model.fit(X_train, y_train)
pred = model.predict(X_test)
acc = accuracy_score(y_test, pred)
print(f"Accuracy: {acc:.4f}")
print(classification_report(y_test, pred, zero_division=0))
joblib.dump(model, ROOT / "outputs" / "skill_gap_model.joblib")
with open(ROOT / "outputs" / "model_accuracy.txt", "w") as f:
    f.write(f"Model: Logistic Regression\nTest accuracy: {acc:.4f}\n")
